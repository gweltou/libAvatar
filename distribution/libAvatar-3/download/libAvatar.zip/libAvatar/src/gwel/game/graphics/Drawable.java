package gwel.game.graphics;


public interface Drawable {
    void draw(Renderer renderer);
    void drawSelected(PRenderer renderer);
}
